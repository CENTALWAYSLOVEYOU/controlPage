(function($) {

    "use strict";


})(jQuery);